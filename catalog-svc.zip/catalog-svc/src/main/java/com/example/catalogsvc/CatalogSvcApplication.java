package com.example.catalogsvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogSvcApplication.class, args);
	}

}
