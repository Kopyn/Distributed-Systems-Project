package com.example.productsvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
